# CG_Raytracer

Advanced Graphics tutorials using Raytracer Framework in C++. Courses and source code provided by Tobias Isenberg, INRIA.

# Members

Exercices made by Tristan HERNANT and Shankar SIVAGNA

# Week numbers

Assignment 1 : from 11/20/2017 to 11/26/2017
Assignment 2 : from 11/27/2017 to 11/03/2017
Assignment 3 : from 12/04/2017 to 12/10/2017
Assignment 4 . from 12/11/2017 to 12/17/2017