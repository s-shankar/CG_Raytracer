# CG_Raytracer

Advanced Graphics tutorials using Raytracer Framework in C++. Courses and source code provided by Tobias Isenberg, INRIA.

# Members

Exercices made by Tristan HERNANT and Shankar SIVAGNA

# Week numbers

Assignement 1 : from 11/20/2017 to 11/26/2017